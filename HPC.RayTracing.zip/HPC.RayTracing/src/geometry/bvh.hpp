#pragma once
#include "geometry/hittable.hpp"
#include <vector>
#include <memory>

class bvh_node : public hittable {
public:
    bvh_node() {}
    bvh_node(std::vector<shared_ptr<hittable>>& objects, size_t start, size_t end);
    bool hit(const ray& r, interval ray_t, hit_record& rec) const override;
    bool bounding_box(aabb& output_box) const override;
private:
    shared_ptr<hittable> left;
    shared_ptr<hittable> right;
    aabb box;
};
