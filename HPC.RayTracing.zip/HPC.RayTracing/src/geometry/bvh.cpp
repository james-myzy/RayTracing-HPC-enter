#include "geometry/bvh.hpp"
#include <algorithm>

bvh_node::bvh_node(std::vector<shared_ptr<hittable>>& objects, size_t start, size_t end) {
    aabb total_box;
    bool first = true;
    for (size_t i = start; i < end; ++i) {
        aabb temp_box;
        if (!objects[i]->bounding_box(temp_box)) continue;
        total_box = first ? temp_box : aabb::surrounding_box(total_box, temp_box);
        first = false;
    }
    int axis = total_box.longest_axis();

    auto comparator = [axis](const shared_ptr<hittable>& a, const shared_ptr<hittable>& b) {
        aabb box_a, box_b;
        if (!a->bounding_box(box_a) || !b->bounding_box(box_b)) return false;
        return box_a.axis_interval(axis).min < box_b.axis_interval(axis).min;
    };

    size_t object_span = end - start;
    if (object_span == 1) { left = right = objects[start]; }
    else if (object_span == 2) { left = objects[start]; right = objects[start + 1]; }
    else {
        std::sort(objects.begin() + start, objects.begin() + end, comparator);
        size_t mid = start + object_span / 2;
        left = make_shared<bvh_node>(objects, start, mid);
        right = make_shared<bvh_node>(objects, mid, end);
    }
    aabb box_left, box_right;
    left->bounding_box(box_left);
    right->bounding_box(box_right);
    box = aabb::surrounding_box(box_left, box_right);
}

bool bvh_node::hit(const ray& r, interval ray_t, hit_record& rec) const {
    if (!box.hit(r, ray_t)) return false;
    bool hit_left = left->hit(r, ray_t, rec);
    bool hit_right = right->hit(r, interval(ray_t.min, hit_left ? rec.t : ray_t.max), rec);
    return hit_left || hit_right;
}

bool bvh_node::bounding_box(aabb& output_box) const { output_box = box; return true; }
