#include "geometry/hittable_list.hpp"

void hittable_list::initialize() {}

bool hittable_list::hit(const ray &r, interval ray_t, hit_record &rec) const
{
    if (!bvh_built && objects.size() > 1) {
        std::lock_guard<std::mutex> lock(*bvh_mutex);
	if(!bvh_built) {

	        bvh_root = make_shared<bvh_node>(const_cast<std::vector<shared_ptr<hittable>>&>(objects), 0, objects.size());
        	bvh_built = true;
	}
    }
    if (bvh_built && bvh_root) {
        return bvh_root->hit(r, ray_t, rec);
    }
    
    hit_record temp_rec;
    bool hit_anything = false;
    auto closest_so_far = ray_t.max;
    for(const auto &object : objects)
    {
        if(object->hit(r, interval(ray_t.min, closest_so_far), temp_rec))
        {
            hit_anything = true;
            closest_so_far = temp_rec.t;
            rec = temp_rec;
        }
    }
    return hit_anything;
}

bool hittable_list::bounding_box(aabb &output_box) const
{
    if (objects.empty()) return false;
    aabb temp_box;
    bool first_box = true;
    for (const auto &object : objects)
    {
        if (!object->bounding_box(temp_box)) return false;
        output_box = first_box ? temp_box : aabb::surrounding_box(output_box, temp_box);
        first_box = false;
    }
    return true;
}
