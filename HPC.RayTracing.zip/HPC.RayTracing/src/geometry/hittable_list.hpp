#pragma once

#include "geometry/hittable.hpp"
#include "geometry/bvh.hpp"
#include <vector>
#include<mutex>
class hittable_list : public hittable
{
public:
    std::vector<shared_ptr<hittable>> objects;

    hittable_list() {}
    hittable_list(const shared_ptr<hittable> &object)
    {
        add(object);
    }

    void clear()
    {
        objects.clear();
    }

    void add(const shared_ptr<hittable> &object)
    {
        objects.push_back(object);
    }

    void initialize();
    bool bounding_box(aabb &output_box) const override;
    bool hit(const ray &r, interval ray_t, hit_record &rec) const override;
private:
    mutable std:: shared_ptr<std::mutex>  bvh_mutex=std::make_shared<std::mutex>();
    mutable shared_ptr<hittable> bvh_root;
    mutable bool bvh_built = false;
};
