
#pragma once
#include "math/vec3.hpp"
#include "geometry/ray.hpp"
#include "math/interval.hpp"
#include <cmath>

class aabb {
public:
    interval x, y, z;
    aabb() {}
    aabb(const interval& x, const interval& y, const interval& z) : x(x), y(y), z(z) {}
    aabb(const point3& a, const point3& b) {
        x = (a[0] <= b[0]) ? interval(a[0], b[0]) : interval(b[0], a[0]);
        y = (a[1] <= b[1]) ? interval(a[1], b[1]) : interval(b[1], a[1]);
        z = (a[2] <= b[2]) ? interval(a[2], b[2]) : interval(b[2], a[2]);
    }
    const interval& axis_interval(int n) const { if (n == 1) return y; if (n == 2) return z; return x; }
    bool hit(const ray& r, interval ray_t) const {
        const point3& ray_orig = r.origin();
        const vec3& ray_dir = r.direction();
        for (int a = 0; a < 3; a++) {
            const interval& ax = axis_interval(a);
            const double adinv = 1.0 / ray_dir[a];
            auto t0 = (ax.min - ray_orig[a]) * adinv;
            auto t1 = (ax.max - ray_orig[a]) * adinv;
            if (t0 < t1) { if (t0 > ray_t.min) ray_t.min = t0; if (t1 < ray_t.max) ray_t.max = t1; }
            else { if (t1 > ray_t.min) ray_t.min = t1; if (t0 < ray_t.max) ray_t.max = t0; }
            if (ray_t.max <= ray_t.min) return false;
        }
        return true;
    }
    int longest_axis() const {
        if (x.max - x.min > y.max - y.min) return (x.max - x.min > z.max - z.min) ? 0 : 2;
        else return (y.max - y.min > z.max - z.min) ? 1 : 2;
    }
    static aabb surrounding_box(const aabb& box0, const aabb& box1) {
        point3 small(fmin(box0.x.min, box1.x.min), fmin(box0.y.min, box1.y.min), fmin(box0.z.min, box1.z.min));
        point3 big(fmax(box0.x.max, box1.x.max), fmax(box0.y.max, box1.y.max), fmax(box0.z.max, box1.z.max));
        return aabb(small, big);
    }
};
