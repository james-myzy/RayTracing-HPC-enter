#include <cmath>
#include <iostream>
#include <thread>
#include <atomic>
#include <vector>
#include "material/material.hpp"
#include "math/color.hpp"
#include "render/camera.hpp"
    
void camera::render(const hittable &world, std::ostream &out)
{
    out << "P3\n" << image_width << ' ' << image_height << "\n255\n";

    // 1. 分配全图缓冲区，避免多线程同时写文件导致画面错乱
    std::vector<color> framebuffer(image_width * image_height);
    
    // 2. 原子计数器，用于让多个线程动态抢着画不同的行
    std::atomic<int> next_row{0};

    // 3. 定义每个线程要做的工作
    auto worker = [&]() {
        std::vector<color> thread_line(image_width); // 线程独立的行缓冲
        while (true) {
            int j = next_row.fetch_add(1); // 抢一行来画
            if (j >= image_height) break;   // 画完了就退出线程

            for (int i = 0; i < image_width; i++) {
                // 保持原版的随机数初始化：每个像素只初始化一次！
                begin_pixel_random(static_cast<std::uint64_t>(j) * static_cast<std::uint64_t>(image_width) + static_cast<std::uint64_t>(i));
                color pixel_color(0, 0, 0);
                for (int sample = 0; sample < samples_per_pixel; sample++) {
                    ray r = get_ray(i, j);
                    pixel_color += ray_color(r, max_depth, world);
                }
                thread_line[i] = pixel_samples_scale * pixel_color;
            }
            // 把算好的这一行，写入全图缓冲区
            for (int i = 0; i < image_width; i++) {
                framebuffer[j * image_width + i] = thread_line[i];
            }
        }
    };

    // 4. 启动所有 CPU 核心的线程
    int num_threads = std::thread::hardware_concurrency();
    if (num_threads == 0) num_threads = 4; // 保底
    std::vector<std::thread> threads;
    for (int t = 0; t < num_threads; ++t) {
        threads.emplace_back(worker);
    }

    // 5. 等待所有线程画完
    for (auto &th : threads) {
        th.join();
    }

    // 6. 主线程按顺序输出 PPM 文件（保证文件格式正确）
    for (int j = 0; j < image_height; j++) {
        std::clog << "\rScanlines remaining: " << (image_height - j) << ' ' << std::flush;
        for (int i = 0; i < image_width; i++) {
            write_color(out, framebuffer[j * image_width + i]);
        }
    }
    std::clog << "\rDone.                 \n";
}
void camera::initialize()
{
    line.resize(image_width);
    image_height = int(image_width / aspect_ratio);
    image_height = (image_height < 1) ? 1 : image_height;

    center = lookfrom;
    pixel_samples_scale = 1.0 / samples_per_pixel;

    auto theta = degrees_to_radians(vfov);
    auto h = std::tan(theta / 2);
    auto viewport_height = 2 * h * focus_dist;
    auto viewport_width = viewport_height * (double(image_width) / image_height);

    w = unit_vector(lookfrom - lookat);
    u = unit_vector(cross(vup, w));
    v = cross(w, u);

    vec3 viewport_u = viewport_width * u;
    vec3 viewport_v = viewport_height * -v; // Image rows run downward.

    pixel_delta_u = viewport_u / image_width;
    pixel_delta_v = viewport_v / image_height;

    auto viewport_upper_left = center - (focus_dist * w) - viewport_u / 2 - viewport_v / 2;
    pixel00_loc = viewport_upper_left + 0.5 * (pixel_delta_u + pixel_delta_v);

    auto defocus_radius = focus_dist * std::tan(degrees_to_radians(defocus_angle / 2));
    defocus_disk_u = u * defocus_radius;
    defocus_disk_v = v * defocus_radius;
}

ray camera::get_ray(int i, int j) const
{
    // Jitter the pixel target and sample the lens for depth of field.
    auto offset = sample_square();
    auto pixel_sample = pixel00_loc + ((i + offset.x()) * pixel_delta_u) + ((j + offset.y()) * pixel_delta_v);

    auto ray_origin = (defocus_angle <= 0) ? center : defocus_disk_sample();
    auto ray_direction = pixel_sample - ray_origin;

    return ray(ray_origin, ray_direction);
}

vec3 camera::sample_square() const
{
    // Braced initialization fixes the order of random draws (x, then y).
    return vec3{random_double() - 0.5, random_double() - 0.5, 0};
}

point3 camera::defocus_disk_sample() const
{
    auto p = random_in_unit_disk();
    return center + (p[0] * defocus_disk_u) + (p[1] * defocus_disk_v);
}

color camera::ray_color(const ray &r, int depth, const hittable &world) const
{
    if(depth <= 0)
        return color(0, 0, 0);
    hit_record rec;

    if(world.hit(r, interval(0.001, infinity), rec))
    {
        ray scattered;
        color attenuation;
        if(rec.mat->scatter(r, rec, attenuation, scattered))
            return attenuation * ray_color(scattered, depth - 1, world);
        return color(0, 0, 0);
    }

    vec3 unit_direction = unit_vector(r.direction());
    auto a = 0.5 * (unit_direction.y() + 1.0);
    return (1.0 - a) * color(1.0, 1.0, 1.0) + a * color(0.5, 0.7, 1.0);
}
